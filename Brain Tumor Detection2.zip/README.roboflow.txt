
Brain Tumor Detection - v2 2022-05-25 8:02pm
==============================

This dataset was exported via roboflow.ai on May 25, 2022 at 1:03 PM GMT

It includes 597 images.
Brain-tumor are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

The following augmentation was applied to create 3 versions of each source image:
* 50% probability of horizontal flip
* 50% probability of vertical flip
* Equal probability of one of the following 90-degree rotations: none, clockwise, counter-clockwise, upside-down
* Randomly crop between 0 and 20 percent of the image
* Random rotation of between -45 and +45 degrees
* Random brigthness adjustment of between -35 and +35 percent


